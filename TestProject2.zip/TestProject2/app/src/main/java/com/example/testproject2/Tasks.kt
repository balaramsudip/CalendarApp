package com.example.testproject2

class Tasks {

    var name: String = ""
    var date: String = ""
    var time: String = ""
    var desc: String = ""

    constructor(name: String, date:String, time:String, desc:String){
        this.name = name
        this.date = date
        this.time = time
        this.desc = desc
    }

    constructor(){

    }
}