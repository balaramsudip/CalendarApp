package com.example.testproject2

enum class SortType {
    NAME,
    DATE,
    TIME,
    DESCRIPTION
}