package com.example.testproject2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import java.lang.Exception

class AddActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)
        val newButton = findViewById<Button>(R.id.finalAddButton)
        val newName = findViewById<EditText>(R.id.Name)
        val newDescription = findViewById<EditText>(R.id.Description)
        val newDate = findViewById<EditText>(R.id.Date)
        val newTime = findViewById<EditText>(R.id.Time)

        var context = this

        newButton.setOnClickListener{
            if (newName.text.toString().isNotEmpty() &&
                newDate.text.toString().isNotEmpty() &&
                newTime.text.toString().isNotEmpty() &&
                newDescription.text.toString().isNotEmpty()
            ){

                var tasks = Tasks(newName.text.toString(), newDate.text.toString(), newTime.text.toString(), newDescription.text.toString())
                var db = TasksHandler(context)
                db.insertData(tasks)
            }

            val intent = Intent(this@AddActivity, MainActivity::class.java)
            startActivity(intent)
        }
    }

}