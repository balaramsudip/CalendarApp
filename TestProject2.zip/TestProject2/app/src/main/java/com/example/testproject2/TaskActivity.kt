package com.example.testproject2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class TaskActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task)
        var title = findViewById<TextView>(R.id.taskName)
        var descLabel = findViewById<TextView>(R.id.descLabel)
        var fullDescription = findViewById<TextView>(R.id.desc)
        var date = findViewById<TextView>(R.id.date)
        var time = findViewById<TextView>(R.id.time)
        var deleteButton = findViewById<Button>(R.id.deleteButton)

        var descriptionText = intent.getStringExtra("DESC")
        fullDescription.text = "$descriptionText"

        var dateText = intent.getStringExtra("DATE")
        date.text = "$dateText"

        var timeText = intent.getStringExtra("TIME")
        time.text = "$timeText"

        var name = intent.getStringExtra("NAME")
        title.text = "$name"

        var context = this
        var db = TasksHandler(context)

        deleteButton.setOnClickListener{
            db.deleteData(name.toString())
            val intent = Intent(this@TaskActivity, MainActivity::class.java)
            startActivity(intent)
        }
    }

}