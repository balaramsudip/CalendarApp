package com.example.testproject2

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import kotlinx.coroutines.handleCoroutineException
import kotlinx.coroutines.launch
import java.lang.Exception


class ToDoListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val context: Context = this

        setContentView(R.layout.activity_todolist)
        var listTitle = findViewById<TextView>(R.id.listTitle)
        var day = intent.getStringExtra("DAY")
        var month = intent.getStringExtra("MONTH")
        var year = intent.getStringExtra("YEAR")
        val selectedDate = intent.getStringExtra("SELECTED_DATE")
        listTitle.text = "To-do list of $selectedDate"
        var todoList = findViewById<RecyclerView>(R.id.toDoList)
        todoList.layoutManager = LinearLayoutManager(this)
        val adapter = ToDoListAdapter()
        todoList.adapter = adapter
        var addButton = findViewById<Button>(R.id.addButton)

        var db = TasksHandler(context)
        val cursor: Cursor = db.readData()
        var list : MutableList<Tasks> = ArrayList()

        if(cursor.moveToFirst()){
            do {
                var task = Tasks()
                task.name = cursor.getString(cursor.getColumnIndexOrThrow("name"))
                task.date = cursor.getString(cursor.getColumnIndexOrThrow("date"))
                task.time = cursor.getString(cursor.getColumnIndexOrThrow("time"))
                task.desc = cursor.getString(cursor.getColumnIndexOrThrow("description"))
                list.add(task)

            } while(cursor.moveToNext())
        } else{
            Toast.makeText(this, "No data available", Toast.LENGTH_SHORT).show()
        }

        var submitList: MutableList<Tasks> = ArrayList()
        for(i in list){
            if(i.date == selectedDate){
                submitList.add(i)
            }
        }

        adapter.submitList(submitList)

        addButton.setOnClickListener{
            val intent = Intent(this@ToDoListActivity, AddActivity::class.java)
            startActivity(intent)
        }
    }
}