package com.example.testproject2

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast

class TasksHandler (var context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, 1) {

    companion object{
        val DATABASE_NAME = "CalendarDatabase"
        val TABLE_NAME = "Tasks"
        val COL_NAME = "name"
        val COL_DATE = "date"
        val COL_TIME = "time"
        val COL_DESC = "description"
    }

    override fun onCreate(db: SQLiteDatabase) {

        val createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_NAME + " TEXT, " +
                COL_DATE + " TEXT, " +
                COL_TIME + " TEXT, " +
                COL_DESC + " TEXT)"

        db.execSQL(createTable)

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }

    fun insertData(tasks: Tasks){
        val db = this.writableDatabase
        var contentValues = ContentValues()
        contentValues.put(COL_DATE, tasks.date)
        contentValues.put(COL_DESC, tasks.desc)
        contentValues.put(COL_NAME, tasks.name)
        contentValues.put(COL_TIME, tasks.time)
        var result = db.insert(TABLE_NAME, null, contentValues)
        if(result == -1.toLong()){
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Success ", Toast.LENGTH_SHORT).show()
        }
    }

    fun readData(): Cursor {
        val db = readableDatabase
        // Specify the columns you want to retrieve
        val projection = arrayOf(COL_NAME, COL_DATE, COL_TIME, COL_DESC)
        // Query the database
        return db.query(TABLE_NAME, projection, null, null, null, null, null)
    }

    fun deleteData(name: String){
        val db = this.writableDatabase
        db.delete(TABLE_NAME, "$COL_NAME=?", arrayOf(name))
        db.close()
    }

}