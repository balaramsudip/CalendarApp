package com.example.testproject2

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room

class ToDoListAdapter : RecyclerView.Adapter<ToDoListAdapter.ToDoViewHolder>() {

    var list: List<Tasks> = emptyList()

    class ToDoViewHolder(val view: View) : RecyclerView.ViewHolder(view){
        var toDoList = view.findViewById<TextView>(R.id.todoListItem)

    }

    fun submitList(newList: List<Tasks>) {
        list = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ToDoViewHolder {
        return ToDoViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_view, parent, false ))
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ToDoViewHolder, position: Int) {
        val task = list[position]
        holder.toDoList.text = task.name
        holder.toDoList.setOnClickListener{
            val intent = Intent(holder.itemView.context, TaskActivity::class.java)
            intent.putExtra("NAME", task.name)
            intent.putExtra("DATE", task.date)
            intent.putExtra("TIME", task.time)
            intent.putExtra("DESC", task.desc)
            holder.itemView.context.startActivity(intent)
        }
    }
}