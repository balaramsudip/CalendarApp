package com.example.testproject2

import android.content.Intent
import android.os.Bundle
import android.widget.CalendarView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Calendar

class MainActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var calendarView = findViewById<CalendarView>(R.id.calendarView)
        var calendar = Calendar.getInstance()

        calendarView.setOnDateChangeListener { view, year, month, dayOfMonth ->
            val selectedDate = "$dayOfMonth/${month + 1}/$year"
            val intent = Intent(this@MainActivity, ToDoListActivity::class.java)
            intent.putExtra("DAY", dayOfMonth)
            intent.putExtra("MONTH", month)
            intent.putExtra("YEAR", year)
            intent.putExtra("SELECTED_DATE", selectedDate)
            startActivity(intent)
        }
    }
}